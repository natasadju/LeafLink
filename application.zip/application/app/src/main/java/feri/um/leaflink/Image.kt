package feri.um.leaflink

data class Image(
    val id: String,
    val imageUrl: String,
    val eventId: String
)
