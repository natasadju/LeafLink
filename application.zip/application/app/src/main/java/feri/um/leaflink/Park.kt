package feri.um.leaflink

data class Park(
    val _id: String,
    val name: String,
    val parkId: Int,
    val lat: String,
    val long: String
)