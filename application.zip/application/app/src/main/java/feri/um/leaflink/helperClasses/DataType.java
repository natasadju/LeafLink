package feri.um.leaflink.helperClasses;

public enum DataType {
    EVENTS, AIR_QUALITY
}
