package feri.um.leaflink

data class ParksResponse(
    val parks: List<Park>
)