package feri.um.leaflink

import org.osmdroid.util.GeoPoint

class ExtremeEvent(
    val message: String,
    val category: String,
    val location: String,
    val date: String
) {
}